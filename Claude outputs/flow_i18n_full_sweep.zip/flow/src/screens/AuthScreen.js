import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { View, Text, TouchableOpacity, Alert, Image, StyleSheet, Dimensions, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { supabase } from '../shared/lib/supabase';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons, FontAwesome5 } from '@expo/vector-icons';
import { CustomButton, CustomInput } from '../shared';
import * as WebBrowser from 'expo-web-browser';
import { makeRedirectUri } from 'expo-auth-session';
import * as QueryParams from 'expo-auth-session/build/QueryParams';

WebBrowser.maybeCompleteAuthSession();

const { width, height } = Dimensions.get('window');

export default function AuthScreen() {
  const { t } = useTranslation();
  const insets = useSafeAreaInsets();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [isLogin, setIsLogin] = useState(true);

  // Clear any stuck sessions on mount just in case (optional, based on recent issues)
  useEffect(() => {
    const checkSession = async () => {
      const { data, error } = await supabase.auth.getSession();
      if (error && error.message.includes('Refresh Token Not Found')) {
        await supabase.auth.signOut();
      }
    };
    checkSession();
  }, []);

  async function handleGoogleLogin() {
    setLoading(true);
    try {
      // Expo Go'da otomatik olarak exp://..., canlıda workigomflow://... üretir
      const redirectTo = makeRedirectUri();
      // Supabase'in bu URL'i kabul etmesi için dashboard'da whiteliste eklenmesi gerekir!
      console.log('Redirect URI (Supabase panele eklenmeli):', redirectTo);

      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo,
          skipBrowserRedirect: true,
        },
      });

      if (error) throw error;
      if (!data?.url) throw new Error(t('authScreen.errors.oauthUrlFailed'));
      
      console.log('Supabase OAuth URL:', data.url);

      const res = await WebBrowser.openAuthSessionAsync(data.url, redirectTo);

      if (res.type === 'success') {
        const { url } = res;
        const { params, errorCode } = QueryParams.getQueryParams(url);

        if (errorCode) throw new Error(errorCode);
        const { access_token, refresh_token } = params;

        if (access_token && refresh_token) {
          const { error: sessionError } = await supabase.auth.setSession({
            access_token,
            refresh_token,
          });
          if (sessionError) throw sessionError;
        }
      }
    } catch (error) {
      Alert.alert(t('authScreen.errors.googleLoginTitle'), error.message);
    } finally {
      setLoading(false);
    }
  }

  async function signInWithEmail() {
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({
      email: email,
      password: password,
    });
    if (error) Alert.alert(t('authScreen.errors.loginTitle'), error.message);
    setLoading(false);
  }

  async function signUpWithEmail() {
    if (!name) {
      Alert.alert(t('authScreen.errors.genericTitle'), t('authScreen.errors.nameRequired'));
      return;
    }
    if (!phone) {
      Alert.alert(t('authScreen.errors.genericTitle'), t('authScreen.errors.phoneRequired'));
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email: email,
      password: password,
      options: {
        data: {
          phone: phone,
          display_name: name,
          full_name: name,
        },
      },
    });
    if (error) {
      Alert.alert(t('authScreen.errors.signupTitle'), error.message);
    } else {
      Alert.alert(t('authScreen.success.title'), t('authScreen.success.signupMessage'));
      setIsLogin(true);
    }
    setLoading(false);
  }

  return (
    <View style={[styles.container, { backgroundColor: '#17151A' }]}>
      {/* Premium Dark Background */}
      <View style={StyleSheet.absoluteFillObject} className="bg-[#17151A]" />
      
      {/* Background Decorative Gradients */}
      <View className="absolute top-0 left-0 right-0 h-[60%] opacity-20">
        <LinearGradient
          colors={['#22B573', 'transparent']}
          style={{ flex: 1 }}
          start={{ x: 0.5, y: 0 }}
          end={{ x: 0.5, y: 1 }}
        />
      </View>
      <View className="absolute bottom-0 left-0 right-0 h-[40%] opacity-10">
        <LinearGradient
          colors={['transparent', '#E8A8CD']}
          style={{ flex: 1 }}
          start={{ x: 0.5, y: 0 }}
          end={{ x: 0.5, y: 1 }}
        />
      </View>

      <KeyboardAvoidingView 
        style={{ flex: 1 }} 
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView 
          contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', paddingTop: insets.top + 16, paddingBottom: insets.bottom + 16 }}
          showsVerticalScrollIndicator={false}
          className="px-6"
        >
          
          {/* LOGO & BRANDING */}
          <View className="items-center mb-6">
          <View style={styles.logoContainer}>
            <Image 
              source={require('../../image/logo2.png')} 
              style={styles.logoImage} 
              resizeMode="contain"
            />
          </View>
        </View>

        {/* GLASSMORPHISM CARD */}
        <View style={styles.glassCard} className="rounded-3xl p-6 shadow-2xl">
          
          <Text className="text-white text-2xl font-bold mb-6 text-center">
            {isLogin ? t('authScreen.title.login') : t('authScreen.title.signup')}
          </Text>

          {/* GOOGLE LOGIN BUTTON */}
          <TouchableOpacity 
            onPress={handleGoogleLogin} 
            disabled={loading}
            style={styles.googleBtn}
            className="flex-row items-center justify-center py-3.5 rounded-xl mb-6"
          >
            <FontAwesome5 name="google" size={18} color="#fff" style={{ marginRight: 12 }} />
            <Text className="text-white font-bold text-base">{t('authScreen.googleButton')}</Text>
          </TouchableOpacity>

          {/* DIVIDER */}
          <View className="flex-row items-center mb-6">
            <View className="flex-1 h-[1px] bg-white/10" />
            <Text className="text-[#A79E96] text-xs px-4">{t('authScreen.dividerText')}</Text>
            <View className="flex-1 h-[1px] bg-white/10" />
          </View>

          {/* EMAIL & PASSWORD INPUTS */}
          <CustomInput
            label={t('authScreen.emailLabel')}
            onChangeText={(text) => setEmail(text)}
            value={email}
            placeholder={t('authScreen.emailPlaceholder')}
            autoCapitalize="none"
            keyboardType="email-address"
            containerClassName="mb-4"
          />

          {!isLogin && (
            <>
              <CustomInput
                label={t('authScreen.nameLabel')}
                onChangeText={(text) => setName(text)}
                value={name}
                placeholder={t('authScreen.namePlaceholder')}
                autoCapitalize="words"
                containerClassName="mb-4"
              />
              <CustomInput
                label={t('authScreen.phoneLabel')}
                onChangeText={(text) => setPhone(text)}
                value={phone}
                placeholder={t('authScreen.phonePlaceholder')}
                keyboardType="phone-pad"
                containerClassName="mb-4"
              />
            </>
          )}

          <CustomInput
            label={t('authScreen.passwordLabel')}
            onChangeText={(text) => setPassword(text)}
            value={password}
            secureTextEntry={true}
            placeholder={t('authScreen.passwordPlaceholder')}
            autoCapitalize="none"
            containerClassName="mb-8"
          />

          <CustomButton
            title={isLogin ? t('authScreen.loginButton') : t('authScreen.signupButton')}
            onPress={() => isLogin ? signInWithEmail() : signUpWithEmail()}
            isLoading={loading}
            className="w-full shadow-[0_0_15px_rgba(0,218,243,0.3)] mb-4"
            style={{ backgroundColor: '#22B573' }}
            textClassName="text-black font-extrabold"
          />

          <TouchableOpacity onPress={() => setIsLogin(!isLogin)} className="items-center mt-2">
            <Text className="text-[#A79E96] text-sm">
              {isLogin ? t('authScreen.noAccountText') : t('authScreen.hasAccountText')}
              <Text className="text-[#22B573] font-bold">
                {isLogin ? t('authScreen.signupButton') : t('authScreen.loginButton')}
              </Text>
            </Text>
          </TouchableOpacity>
          
        </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  logoContainer: {
    width: '100%',
    height: 90,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoImage: {
    width: '80%',
    height: '100%',
  },
  glassCard: {
    backgroundColor: 'rgba(39, 42, 46, 0.5)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.05)',
  },
  googleBtn: {
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.15)',
  },
  container: {
    flex: 1,
  }
});
