"use client";

import { useState } from "react";
import { useTranslations } from "next-intl";
import { APP_STORE_URL, PLAY_STORE_URL } from "@/lib/appStoreLinks";

// Faz 5 (06.09.2026): Bilinçli ürün kararı — flowweb'in dashboard sayfaları
// tam responsive hale getirilmiyor (bkz. README "Faz 5" kaydı). Bunun yerine,
// telefon genişliğindeki (< md / 768px) ziyaretçilere bu ekran gösterilip
// mobil uygulamaya (App Store / Google Play) yönlendiriliyor. "Yine de
// tarayıcıda devam et" bir kaçış kapısı olarak KALICI biçimde bırakıldı —
// şifre sıfırlama/davet linki gibi kritik akışları telefon tarayıcısından
// tamamen kilitlememek için (bkz. Faz 4 sonrası tartışma).
//
// Bu bileşen kök layout.tsx'te NextIntlClientProvider'ın içinde, {children}'ı
// sarmalayarak kullanılıyor — hem /login hem tüm (dashboard) rotalarını
// kapsıyor. "dismissed" state'i sadece bu client component'in ömrü boyunca
// yaşıyor (kalıcı cookie/localStorage YOK, bilinçli tercih): App Router'da
// bu kök layout sayfalar arası client-side navigasyonda yeniden mount
// edilmediği için kullanıcı "devam et"e bastıktan sonra panel içinde
// gezinirken tekrar tekrar bu ekranı görmüyor; sekmeyi kapatıp yeniden
// açtığında (veya tam sayfa yenilemede) ekran tekrar çıkar — bu kasıtlı,
// çünkü amaç "birazcık sürtünme yaratıp app'e yönlendirmek", tam engelleme
// değil.
export default function MobileAppGate({ children }: { children: React.ReactNode }) {
  const [dismissed, setDismissed] = useState(false);
  const t = useTranslations("mobileGate");

  return (
    <>
      {!dismissed && (
        <div
          className="md:hidden fixed inset-0 z-[9999] flex flex-col items-center justify-center gap-7 bg-background px-7 text-center overflow-y-auto py-10"
        >
          <img src="/logo.png" alt="Workigom Flow" className="h-11 w-auto object-contain" />

          <div className="flex flex-col gap-3 max-w-xs">
            <span className="text-[11px] font-semibold tracking-[0.14em] text-primary uppercase">
              {t("eyebrow")}
            </span>
            <h1 className="text-xl font-bold text-on-background leading-snug">{t("title")}</h1>
            <p className="text-sm text-on-surface-variant leading-relaxed">{t("subtitle")}</p>
          </div>

          <div className="flex flex-col gap-3 w-full max-w-xs">
            <StoreBadge href={APP_STORE_URL} label={t("appStoreBadge")} comingSoonLabel={t("comingSoon")} icon="apple" />
            <StoreBadge href={PLAY_STORE_URL} label={t("playStoreBadge")} comingSoonLabel={t("comingSoon")} icon="play" />
          </div>

          <button
            type="button"
            onClick={() => setDismissed(true)}
            className="text-xs text-on-surface-variant underline underline-offset-4 decoration-dotted hover:text-on-background transition-colors mt-2"
          >
            {t("continueAnyway")}
          </button>
        </div>
      )}

      <div className={dismissed ? "contents" : "hidden md:contents"}>{children}</div>
    </>
  );
}

function StoreBadge({
  href,
  label,
  comingSoonLabel,
  icon,
}: {
  href: string | null;
  label: string;
  comingSoonLabel: string;
  icon: "apple" | "play";
}) {
  const content = (
    <>
      <IconGlyph icon={icon} />
      <span className="flex flex-col items-start leading-tight">
        <span className="text-[10px] opacity-70">{href ? "" : comingSoonLabel}</span>
        <span className="text-sm font-semibold">{label}</span>
      </span>
    </>
  );

  const baseClass =
    "flex items-center gap-3 rounded-xl border px-4 py-3 transition-colors";

  if (!href) {
    return (
      <div
        className={`${baseClass} border-white/10 bg-white/[0.03] text-on-surface-variant cursor-not-allowed`}
        aria-disabled="true"
      >
        {content}
      </div>
    );
  }

  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className={`${baseClass} border-white/10 bg-white/[0.06] text-on-background hover:bg-white/[0.1]`}
    >
      {content}
    </a>
  );
}

function IconGlyph({ icon }: { icon: "apple" | "play" }) {
  if (icon === "apple") {
    return (
      <svg width="22" height="22" viewBox="0 0 384 512" fill="currentColor" aria-hidden="true">
        <path d="M318.7 268.7c-.2-36.7 16.4-64.4 50-84.8-18.8-26.9-47.2-41.7-84.7-44.6-35.5-2.8-74.3 20.7-88.5 20.7-15 0-49.4-19.7-76.4-19.7C63.3 141.2 4 184.8 4 273.5q0 39.3 14.4 81.2c12.8 36.7 59 126.7 107.2 125.2 25.2-.6 43-17.9 75.8-17.9 31.8 0 48.3 17.9 76.4 17.9 48.6-.7 90.4-82.5 102.6-119.3-65.2-30.7-61.7-90-61.7-91.9zm-56.6-164.2c27.3-32.4 24.8-61.9 24-72.5-24.1 1.4-52 16.4-67.9 34.9-17.5 19.8-27.8 44.3-25.6 71.9 26.1 2 49.9-11.4 69.5-34.3z" />
      </svg>
    );
  }
  return (
    <svg width="22" height="22" viewBox="0 0 512 512" fill="currentColor" aria-hidden="true">
      <path d="M325.3 234.3L104.6 13l280.8 161.2-60.1 60.1zM47 0C34 6.8 25.3 19.2 25.3 35.3v441.3c0 16.1 8.7 28.5 21.7 35.3l256.6-256L47 0zm425.2 225.6l-58.9-34.1-65.7 64.5 65.7 64.5 60.1-34.1c18-14.3 18-46.5-1.2-60.8zM104.6 499l280.8-161.2-60.1-60.1L104.6 499z" />
    </svg>
  );
}
