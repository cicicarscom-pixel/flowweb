"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useTranslations } from "next-intl";
import AiDataResetPanel from "@/components/settings/AiDataResetPanel";
import { createClient } from "@/lib/supabase/client";
import { saveAiPersonaSettings, getAiPersonaSettings } from "@/actions/aiPersonaSettings";
import { getWahaStatus, startWahaSession, getWahaQrCode, getWahaPairingCode } from "@/actions/waha";
import { getPublishedPersonas, PublicPersona } from "@/actions/personas";
import AICharacterPanel from "@/components/ai-asistan/AICharacterPanel";

// Persona Engine (Phase 5): today's UI still shows a fixed 3-character list
// Persona Engine Phase 6: Removed hardcoded CHARACTER_SLUGS.

function Toggle({ on, onChange }: { on: boolean; onChange: () => void }) {
  return (
    <div
      onClick={onChange}
      style={{
        width: 44, height: 24, borderRadius: 99,
        background: on ? "#22B573" : "rgba(255,255,255,0.1)",
        display: "flex", alignItems: "center", cursor: "pointer",
        padding: 3, transition: "background 0.3s",
      }}
    >
      <div
        style={{
          width: 18, height: 18, borderRadius: "50%",
          background: "#fff",
          transform: on ? "translateX(20px)" : "translateX(0)",
          transition: "transform 0.3s",
          boxShadow: on ? "0 0 10px rgba(0,0,0,0.2)" : "none",
        }}
      />
    </div>
  );
}

export default function BotScreen() {
  const t = useTranslations();
  const supabase = createClient();
  const [botConfig, setBotConfig] = useState({
    whatsapp: false,
    social: false,
    autoReply: true,
    smartRouting: false,
  });
  const [customInstruction, setCustomInstruction] = useState("");
  const [timezone, setTimezone] = useState("Europe/Istanbul");
  const [appointmentModuleEnabled, setAppointmentModuleEnabled] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  
  const [wahaStatus, setWahaStatus] = useState<any>(null);
  const [wahaQrCode, setWahaQrCode] = useState<string | null>(null);
  const [wahaPhone, setWahaPhone] = useState("");
  const [wahaPairingCode, setWahaPairingCode] = useState<string | null>(null);
  const [wahaLoading, setWahaLoading] = useState(false);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;

    // bot_settings still drives the channel toggles below (whatsapp/social
    // active) — untouched by the Persona Engine. Its system_prompt/tone/
    // role/character columns are no longer read here at all ("Tek Yapı"
    // refactor, Eylül 2026 — the "İleri Seviye Ayarlar" panel that used to
    // display system_prompt read-only was removed; that column is still
    // written by nothing and read by nothing on this screen anymore).
    const { data: botData } = await supabase
      .from('bot_settings')
      .select('whatsapp_bot_active, is_active')
      .eq('merchant_id', session.user.id)
      .maybeSingle();

    if (botData) {
      setBotConfig(prev => ({
        ...prev,
        whatsapp: !!botData.whatsapp_bot_active,
        social: !!botData.is_active,
      }));
    }

    // Persona Engine (Phase 5): the merchant's actual saved persona/dial
    // selections now live in organization_ai_settings, not bot_settings.
    const pRes = await getPublishedPersonas();
    if (pRes) {
      setPersonas(pRes);
    }
    setPersonasLoading(false);

    const aiSettings = await getAiPersonaSettings();
    if (aiSettings) {
      if (aiSettings.businessRole) setSelectedRole(aiSettings.businessRole);
      if (aiSettings.tone) setSelectedTone(aiSettings.tone);
      if (aiSettings.customInstruction) setCustomInstruction(aiSettings.customInstruction);
      if (aiSettings.appointmentModuleEnabled !== undefined) setAppointmentModuleEnabled(aiSettings.appointmentModuleEnabled);
      if (aiSettings.characterSlug) setSelectedPersonaSlug(aiSettings.characterSlug);
      if (aiSettings.personaIntensity !== undefined) setPersonaIntensity(aiSettings.personaIntensity);
      if (aiSettings.humorLevel !== undefined) setHumorLevel(aiSettings.humorLevel);
      if (aiSettings.modernAdaptation !== undefined) setModernAdaptation(aiSettings.modernAdaptation);
    }

    const wahaRes = await getWahaStatus();
    if (wahaRes.success && wahaRes.data) {
      setWahaStatus(wahaRes.data.status);
      if (wahaRes.data.me) {
        setWahaPhone(wahaRes.data.me.id.split('@')[0]);
      }
    }
  };

    const handleAppointmentToggle = async () => {
    const newValue = !appointmentModuleEnabled;
    setAppointmentModuleEnabled(newValue);
    
    // Anında veritabanına kaydet (kullanıcı kaydet butonuna basmayı unutabiliyor)
    const characterSlug = selectedPersonaSlug;
    await saveAiPersonaSettings({
      characterSlug,
      businessRole: selectedRole,
      tone: selectedTone,
      customInstruction,
      appointmentModuleEnabled: newValue,
      personaIntensity,
      humorLevel,
      modernAdaptation,
    });
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      // Persona Engine (Phase 5, guardrail #2): this client no longer builds
      // or saves any merged prompt string. It only sends the raw selections
      // — organization_ai_settings.persona_id (resolved server-side from
      // this slug) is what PersonaService/PersonaPromptBuilder render into
      // an actual prompt, on the server, at message time (Phase 2/3).
      // bot_settings.system_prompt/tone/role/character are no longer
      // written from this screen at all.
      const characterSlug = selectedPersonaSlug;

      const result = await saveAiPersonaSettings({
        characterSlug,
        businessRole: selectedRole,
        tone: selectedTone,
        customInstruction,
        appointmentModuleEnabled,
        personaIntensity,
        humorLevel,
        modernAdaptation,
      });

      if (!result.success) {
        alert(t("aiAsistanPage.alerts.saveFailed", { error: result.error ?? t("aiAsistanPage.alerts.unknownError") }));
        return;
      }

      alert(t("aiAsistanPage.alerts.saveSuccess"));
    } catch (error) {
      console.error(error);
      alert(t("aiAsistanPage.alerts.saveError"));
    } finally {
      setIsSaving(false);
    }
  };

  // Poll WAHA status when QR is showing or status is not yet WORKING
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (wahaQrCode || wahaPairingCode || (wahaStatus && wahaStatus !== 'WORKING' && wahaStatus !== 'STOPPED')) {
      interval = setInterval(async () => {
        const wahaRes = await getWahaStatus();
        if (wahaRes.success && wahaRes.data) {
          if (wahaRes.data.status !== wahaStatus) {
            setWahaStatus(wahaRes.data.status);
          }
          if (wahaRes.data.status === 'WORKING') {
            setWahaQrCode(null);
            setWahaPairingCode(null);
            if (wahaRes.data.me) {
              setWahaPhone(wahaRes.data.me.id.split('@')[0]);
            }
          }
        }
      }, 3000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [wahaQrCode, wahaPairingCode, wahaStatus]);

  const handleToggle = async (key: 'social' | 'whatsapp', newValue: boolean) => {
    setBotConfig(c => ({ ...c, [key]: newValue }));
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;
    
    const updateData: any = {};
    if (key === 'social') {
      updateData.is_active = newValue;
      updateData.social_bot_active = newValue;
    }
    if (key === 'whatsapp') updateData.whatsapp_bot_active = newValue;

    // Check if row exists
    const { data: existingData } = await supabase
      .from('bot_settings')
      .select('id')
      .eq('merchant_id', session.user.id)
      .limit(1);

    if (existingData && existingData.length > 0) {
      await supabase.from('bot_settings').update(updateData).eq('merchant_id', session.user.id);
    } else {
      await supabase.from('bot_settings').insert([{ merchant_id: session.user.id, ...updateData }]);
    }
  };

  const handleWahaConnect = async () => {
    setWahaLoading(true);
    setWahaQrCode(null);
    setWahaPairingCode(null);
    
    const startRes = await startWahaSession();
    if (!startRes.success) {
      alert(startRes.error);
      setWahaLoading(false);
      return;
    }
    
    setTimeout(async () => {
      const qrRes = await getWahaQrCode();
      if (qrRes.success && qrRes.data) {
        setWahaQrCode(qrRes.data.data || qrRes.data);
      } else {
        alert(t("aiAsistanPage.alerts.qrFailed", { error: qrRes.error || "" }));
      }
      setWahaLoading(false);
    }, 2000);
  };

  const handleGetPairingCode = async () => {
    if (!wahaPhone.trim()) {
      alert(t("aiAsistanPage.alerts.enterPhone"));
      return;
    }
    setWahaLoading(true);
    setWahaPairingCode(null);

    const pairingRes = await getWahaPairingCode(wahaPhone.trim());
    if (pairingRes.success && pairingRes.data) {
      setWahaPairingCode(pairingRes.data.code);
    } else {
      alert(t("aiAsistanPage.alerts.codeFailed", { error: pairingRes.error || "" }));
    }
    setWahaLoading(false);
  };

  const [selectedRole, setSelectedRole] = useState("Kebapçı");
  const [selectedPersonaSlug, setSelectedPersonaSlug] = useState<string | null>(null);
  const [personas, setPersonas] = useState<PublicPersona[]>([]);
  const [personasLoading, setPersonasLoading] = useState(true);
  const [personaIntensity, setPersonaIntensity] = useState(50);
  const [humorLevel, setHumorLevel] = useState(50);
  const [modernAdaptation, setModernAdaptation] = useState(50);
  const [selectedTone, setSelectedTone] = useState("Standart");
  const [isSimulationActive, setIsSimulationActive] = useState(false);

  const [messages, setMessages] = useState<{role: string, content: string}[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;
    
    setIsSimulationActive(true);
    const newMessages = [...messages, { role: 'user', content: inputValue }];
    setMessages(newMessages);
    setInputValue('');
    setIsTyping(true);

    try {
      // Persona Engine (Phase 4/5): Canlı Test artık gerçek
      // PromptBuilder/AIOrchestrator/ToolRegistry pipeline'ını
      // executionMode "simulation" ile çalıştıran persona-test fonksiyonunu
      // kullanıyor — gemini-chat'e ve elle birleştirilmiş bir system prompt
      // string'ine artık hiç gerek yok. Henüz KAYDEDİLMEMİŞ seçimler
      // (selectedRole/selectedCharacter/selectedTone/customInstruction)
      // doğrudan gönderiliyor, böylece kullanıcı "Kaydet"e basmadan önce
      // önizleme yapabiliyor — bu, Faz 5'in DoD'sinin ("Canlı Test'te
      // görülenle birebir aynı yanıt") tam olarak dayandığı mekanizma.
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        setMessages(prev => [...prev, { role: 'bot', content: t("aiAsistanPage.alerts.sessionNotFound") }]);
        return;
      }

      const { data, error } = await supabase.functions.invoke('persona-test', {
        body: {
          merchantId: session.user.id,
          testMessage: inputValue.trim(),
          personaSlug: selectedPersonaSlug,
          businessRole: selectedRole,
          tone: selectedTone,
          customInstruction: customInstruction,
          appointmentModuleEnabled,
          personaIntensity,
          humorLevel,
          modernAdaptation,
        }
      });

      if (error || data?.error) {
        setMessages(prev => [...prev, { role: 'bot', content: t("aiAsistanPage.alerts.chatError", { error: error?.message || data?.error || t("aiAsistanPage.alerts.unknownErrorChat") }) }]);
      } else {
        setMessages(prev => [...prev, { role: 'bot', content: data?.text || t("aiAsistanPage.alerts.noResponse") }]);
      }
    } catch (e: any) {
      setMessages(prev => [...prev, { role: 'bot', content: t("aiAsistanPage.alerts.systemError") }]);
    } finally {
      setIsTyping(false);
    }
  };



  return (
    <div style={{ padding: "28px 32px", width: "100%", flex: 1 }}>
      {/* Header */}
      <div style={{ marginBottom: 24 }}>
        <h2 style={{ fontSize: 22, fontWeight: 700, marginBottom: 4 }}>{t("aiAsistanPage.header.title")}</h2>
        <p style={{ color: "var(--text-secondary)", fontSize: 14 }}>{t("aiAsistanPage.header.subtitle")}</p>
      </div>

      {/* Top Section: Toggles, Textarea, Bağlı Servisler */}
      <div style={{ display: "flex", flexDirection: "column", gap: 32, marginBottom: 32 }}>




        {/* Bağlı Servisler */}
        <div style={{ position: "relative" }}>
          <div style={{ position: "absolute", right: -4, top: -20, width: 44, height: 44, borderRadius: "50%", background: "rgba(255,255,255,0.1)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 10 }}>
            <span style={{ fontSize: 22, filter: "grayscale(1) brightness(1.5)", opacity: 0.8 }}>⚙️</span>
          </div>
          
          <h3 style={{ fontSize: 16, fontWeight: 700, color: "#fff", marginBottom: 16, padding: "0 4px" }}>{t("aiAsistanPage.connectedServices.title")}</h3>
          <div className="glass" style={{ borderRadius: 20, padding: "20px", border: "1px solid rgba(255,122,89,0.3)", background: "rgba(255,122,89,0.03)", display: "flex", flexDirection: "column", gap: 16 }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
              {/* Google Drive */}
              <div className="glass" style={{ borderRadius: 16, padding: "16px", background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.05)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
                  <span style={{ fontSize: 22 }}>G</span>
                  <div>
                    <p style={{ fontSize: 15, fontWeight: 600, color: "#fff", margin: "0 0 4px 0" }}>{t("aiAsistanPage.connectedServices.googleDrive.title")}</p>
                    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                      <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#EF4444" }} />
                      <span style={{ fontSize: 12, color: "var(--text-secondary)" }}>{t("aiAsistanPage.connectedServices.googleDrive.notConnected")}</span>
                    </div>
                  </div>
                </div>
                <button style={{ background: "rgba(255,255,255,0.1)", border: "none", borderRadius: 99, padding: "8px 20px", color: "#fff", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
                  {t("aiAsistanPage.connectedServices.googleDrive.connect")}
                </button>
              </div>

              {/* WhatsApp */}
              <div className="glass" style={{ borderRadius: 16, padding: "16px", background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.05)", display: "flex", flexDirection: "column", gap: 16 }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
                    <i className="fa-brands fa-whatsapp" style={{ fontSize: 24, color: "#25D366" }}></i>
                    <div>
                      <p style={{ fontSize: 15, fontWeight: 600, color: "#fff", margin: "0 0 4px 0" }}>{t("aiAsistanPage.connectedServices.whatsapp.title")}</p>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <div style={{ width: 8, height: 8, borderRadius: "50%", background: wahaStatus === 'WORKING' ? "#22B573" : "#EF4444" }} />
                        <span style={{ fontSize: 12, color: "var(--text-secondary)" }}>
                          {wahaStatus === 'WORKING' ? t("aiAsistanPage.connectedServices.whatsapp.connected") : (wahaStatus === 'STARTING' ? t("aiAsistanPage.connectedServices.whatsapp.starting") : t("aiAsistanPage.connectedServices.whatsapp.notConnected"))}
                        </span>
                      </div>
                    </div>
                  </div>
                  {wahaStatus !== 'WORKING' ? (
                    <button
                      onClick={handleWahaConnect}
                      disabled={wahaLoading}
                      style={{ background: "rgba(255,255,255,0.1)", border: "none", borderRadius: 99, padding: "8px 20px", color: "#fff", fontSize: 13, fontWeight: 600, cursor: wahaLoading ? "not-allowed" : "pointer", opacity: wahaLoading ? 0.7 : 1 }}>
                      {wahaLoading ? t("aiAsistanPage.connectedServices.whatsapp.processing") : t("aiAsistanPage.connectedServices.whatsapp.connect")}
                    </button>
                  ) : (
                    <button
                      onClick={handleWahaConnect}
                      disabled={wahaLoading}
                      style={{ background: "rgba(34,181,115,0.2)", border: "1px solid rgba(34,181,115,0.4)", borderRadius: 99, padding: "6px 16px", color: "#22B573", fontSize: 12, fontWeight: 600, cursor: wahaLoading ? "not-allowed" : "pointer" }}>
                      {wahaLoading ? t("aiAsistanPage.connectedServices.whatsapp.processing") : t("aiAsistanPage.connectedServices.whatsapp.refresh")}
                    </button>
                  )}
                </div>
                
                {/* QR and Pairing section */}
                {wahaQrCode && (
                  <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 16, marginTop: 12, padding: 16, background: "rgba(0,0,0,0.2)", borderRadius: 12 }}>
                    <p style={{ fontSize: 13, color: "#fff", textAlign: "center" }}>{t("aiAsistanPage.connectedServices.whatsapp.qrInstruction")}</p>
                    <img src={wahaQrCode.startsWith('data:image') ? wahaQrCode : `data:image/png;base64,${wahaQrCode}`} style={{ width: 200, height: 200, borderRadius: 8 }} alt="WAHA QR" />

                    <div style={{ width: "100%", height: 1, background: "rgba(255,255,255,0.1)", margin: "8px 0" }} />
                    <p style={{ fontSize: 13, color: "#fff", textAlign: "center" }}>{t("aiAsistanPage.connectedServices.whatsapp.orConnectWithNumber")}</p>
                    <div style={{ display: "flex", gap: 8, width: "100%" }}>
                      <input
                        type="text"
                        value={wahaPhone}
                        onChange={e => setWahaPhone(e.target.value)}
                        placeholder={t("aiAsistanPage.connectedServices.whatsapp.phonePlaceholder")}
                        style={{ flex: 1, padding: "8px 12px", borderRadius: 8, background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "#fff", outline: "none", fontSize: 13 }}
                      />
                      <button
                        onClick={handleGetPairingCode}
                        disabled={wahaLoading}
                        style={{ padding: "8px 16px", borderRadius: 8, background: "#22B573", color: "#fff", border: "none", fontWeight: 600, fontSize: 13, cursor: wahaLoading ? "not-allowed" : "pointer" }}
                      >
                        {t("aiAsistanPage.connectedServices.whatsapp.getCode")}
                      </button>
                    </div>
                    {wahaPairingCode && (
                      <div style={{ marginTop: 8, padding: 12, background: "rgba(34,181,115,0.1)", border: "1px solid rgba(34,181,115,0.3)", borderRadius: 8, width: "100%", textAlign: "center" }}>
                        <p style={{ fontSize: 12, color: "var(--text-secondary)", marginBottom: 4 }}>{t("aiAsistanPage.connectedServices.whatsapp.confirmCodeLabel")}</p>
                        <p style={{ fontSize: 24, fontWeight: 700, color: "#22B573", letterSpacing: 4 }}>{wahaPairingCode}</p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* WhatsApp Asistanı Toggle */}
            <div style={{ display: "flex", justifyContent: "center", marginTop: 4 }}>
              <div className="glass" style={{ width: "50%", minWidth: 300, borderRadius: 16, padding: "16px 20px", background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.04)" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                  <i className="fa-brands fa-whatsapp" style={{ fontSize: 22, color: "#25D366" }}></i>
                  <span style={{ fontSize: 15, fontWeight: 600, color: "#e5e1e4", flex: 1 }}>{t("aiAsistanPage.connectedServices.toggleLabel")}</span>
                  <Toggle on={botConfig.whatsapp} onChange={() => handleToggle('whatsapp', !botConfig.whatsapp)} />
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>

      {/* Middle Section: 2-Column Grid for AI Kişiliği and Canlı Test */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(400px, 1fr))", gap: 28, alignItems: "stretch", marginBottom: 32 }}>
        
        {/* Left Column: AI Kişiliği & Advanced Settings */}
        <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
          <AICharacterPanel
            selectedRole={selectedRole}
            onSelectRole={setSelectedRole}
            personas={personas}
            personasLoading={personasLoading}
            selectedPersonaSlug={selectedPersonaSlug}
            onSelectPersona={(p) => setSelectedPersonaSlug(p ? p.slug : null)}
            selectedTone={selectedTone}
            onSelectTone={setSelectedTone}
            personaIntensity={personaIntensity}
            onPersonaIntensityChange={setPersonaIntensity}
            humorLevel={humorLevel}
            onHumorLevelChange={setHumorLevel}
            modernAdaptation={modernAdaptation}
            onModernAdaptationChange={setModernAdaptation}
          />

          {/*
            "İleri Seviye Ayarlar" (AdvancedPersonaSettings) paneli kaldırıldı
            ("Tek Yapı" refactor, Eylül 2026). Bu panel zaten Phase 5'ten beri
            hiçbir şey kaydetmiyordu — sadece bot_settings.system_prompt'a
            (artık gerçek bot davranışı için hiç okunmayan bir legacy kolona)
            daha önce yazılmış, dondurulmuş bir metni salt-okunur gösteriyordu.
            Kültürel/dil adaptasyonu artık burada yapılandırılabilir bir ayar
            değil — sunucu tarafında (ledger reposu, PromptBuilder.ts →
            SYSTEM_POLICY madde 1) her merchant için sabit ve kapatılamaz
            şekilde gömülü (bkz. mobil taraftaki aynı temizlik).
          */}

          {/* Saat Dilimi (Timezone) Ayarı */}
          <div className="glass" style={{
            borderRadius: 20, padding: "16px 20px", marginTop: 8,
            border: "1.5px solid rgba(255,122,89,0.5)",
            background: "rgba(255,122,89,0.03)",
            display: "flex", justifyContent: "space-between", alignItems: "center"
          }}>
            <div>
              <h3 style={{ fontSize: 16, fontWeight: 700, color: "#fff", marginBottom: 4 }}>{t("aiAsistanPage.timezone.title")}</h3>
              <p style={{ fontSize: 13, color: "rgba(255,255,255,0.5)", margin: 0 }}>{t("aiAsistanPage.timezone.description")}</p>
            </div>
            <select
              value={timezone}
              onChange={(e) => setTimezone(e.target.value)}
              style={{
                background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,122,89,0.3)",
                color: "#fff", padding: "8px 12px", borderRadius: 8, outline: "none", fontSize: 14,
                cursor: "pointer", minWidth: 200
              }}
            >
              <option value="Europe/Istanbul" style={{ background: "#1a1a1a" }}>{t("aiAsistanPage.timezone.options.turkey")}</option>
              <option value="Europe/London" style={{ background: "#1a1a1a" }}>{t("aiAsistanPage.timezone.options.uk")}</option>
              <option value="Europe/Berlin" style={{ background: "#1a1a1a" }}>{t("aiAsistanPage.timezone.options.germany")}</option>
              <option value="America/New_York" style={{ background: "#1a1a1a" }}>{t("aiAsistanPage.timezone.options.usEast")}</option>
              <option value="America/Los_Angeles" style={{ background: "#1a1a1a" }}>{t("aiAsistanPage.timezone.options.usWest")}</option>
              <option value="Asia/Dubai" style={{ background: "#1a1a1a" }}>{t("aiAsistanPage.timezone.options.uae")}</option>
            </select>
          </div>

            {/* Randevu / Rezervasyon Modülü Ayarı */}
            <div className="glass" style={{ borderRadius: 20, padding: "16px 20px", marginTop: 8, border: "1.5px solid rgba(255,122,89,0.5)", background: "rgba(255,122,89,0.03)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <h3 style={{ fontSize: 16, fontWeight: 700, color: "#fff", marginBottom: 4 }}>{t("aiAsistanPage.appointmentModule.title")}</h3>
                <p style={{ fontSize: 13, color: "rgba(255,255,255,0.5)", margin: 0 }}>{t("aiAsistanPage.appointmentModule.description")}</p>
              </div>
              <Toggle on={appointmentModuleEnabled} onChange={handleAppointmentToggle} />
            </div>

          {/* Asistan Talimatı Oluştur */}
          <div>
            <h3 style={{ fontSize: 16, fontWeight: 700, color: "#fff", marginBottom: 16, padding: "0 4px" }}>{t("aiAsistanPage.customInstruction.title")}</h3>
            <div className="glass" style={{ 
              borderRadius: 24, 
              padding: "16px", 
              background: "rgba(194,71,141,0.03)", 
              border: "2px solid #C2478D",
              boxShadow: "0 0 20px rgba(194,71,141,0.15)"
            }}>
              <textarea
                value={customInstruction}
                onChange={(e) => setCustomInstruction(e.target.value)}
                placeholder={t("aiAsistanPage.customInstruction.placeholder")}
                className="focus:outline-none focus:ring-0 focus:border-transparent"
                style={{
                  width: "100%", minHeight: 110, background: "transparent", border: "none",
                  color: "rgba(255,255,255,0.85)", fontSize: 14, outline: "none", resize: "none",
                  boxShadow: "none"
                }}
              />
            </div>
          </div>

          <button 
            onClick={handleSave}
            disabled={isSaving}
            style={{ 
            background: "linear-gradient(135deg, #C2478D 0%, #FF7A59 100%)",
            border: "1px solid rgba(255,255,255,0.15)",
            borderRadius: 16, 
            padding: "16px", 
            color: "#fff", 
            fontSize: 16, 
            fontWeight: 600,
            letterSpacing: "0.02em",
            cursor: isSaving ? "not-allowed" : "pointer", 
            opacity: isSaving ? 0.7 : 1,
            boxShadow: "0 0 20px rgba(194,71,141,0.25)", 
            marginTop: 8
          }}>
            {isSaving ? t("aiAsistanPage.saveButton.saving") : t("aiAsistanPage.saveButton.save")}
          </button>
        </div>

        {/* Right Column: Canlı Test */}
        <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
          <div className="glass" style={{ borderRadius: 18, border: "1px solid rgba(255,255,255,0.06)", overflow: "hidden", display: "flex", flexDirection: "column", flex: 1, minHeight: 500 }}>
            <div style={{ padding: "16px 20px", borderBottom: "1px solid rgba(255,255,255,0.04)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#22B573", boxShadow: "0 0 8px #22B573" }} />
                <span style={{ fontSize: 15, fontWeight: 700, color: "#fff" }}>{t("aiAsistanPage.liveTest.title")}</span>
              </div>
              <div 
                onClick={() => setIsSimulationActive(!isSimulationActive)}
                style={{ cursor: "pointer", opacity: 0.6, transition: "opacity 0.2s" }}
                onMouseEnter={(e) => e.currentTarget.style.opacity = "1"}
                onMouseLeave={(e) => e.currentTarget.style.opacity = "0.6"}
              >
                <span style={{ fontSize: 16, filter: "grayscale(1) brightness(2)" }}>↻</span>
              </div>
            </div>
            
            <div style={{ flex: 1, background: "rgba(0,0,0,0.2)", display: "flex", flexDirection: "column", padding: "20px 16px", overflowY: "auto", gap: 16 }}>
              {!isSimulationActive && messages.length === 0 ? (
                <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100%" }}>
                   <p style={{ color: "rgba(255,255,255,0.3)", fontSize: 13 }}>{t("aiAsistanPage.liveTest.emptyState")}</p>
                </div>
              ) : (
                <>
                  <div style={{ textAlign: "center", marginBottom: 8 }}>
                    <span style={{ 
                      fontSize: 10, fontWeight: 700, color: "rgba(255,255,255,0.3)", 
                      letterSpacing: "0.1em", border: "1px solid rgba(255,255,255,0.05)",
                      padding: "4px 12px", borderRadius: 99
                    }}>{t("aiAsistanPage.liveTest.simulationStarted")}</span>
                  </div>
                  
                  {messages.map((msg, idx) => (
                    msg.role === 'user' ? (
                      <div key={idx} style={{ alignSelf: "flex-end", maxWidth: "85%" }}>
                        <div style={{ 
                          background: "rgba(255,255,255,0.1)", borderRadius: "16px 16px 2px 16px", 
                          padding: "12px 16px", color: "rgba(255,255,255,0.9)", fontSize: 13, lineHeight: 1.5 
                        }}>
                          {msg.content}
                        </div>
                      </div>
                    ) : (
                      <div key={idx} style={{ alignSelf: "flex-start", maxWidth: "90%" }}>
                        <div style={{ 
                          background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)",
                          borderRadius: "16px 16px 16px 2px", padding: "14px 16px", 
                          color: "rgba(255,255,255,0.85)", fontSize: 13, lineHeight: 1.6 
                        }}>
                          {msg.content}
                        </div>
                      </div>
                    )
                  ))}

                  {isTyping && (
                    <div style={{ alignSelf: "flex-start", display: "flex", gap: 4, padding: "8px 14px", background: "rgba(255,255,255,0.05)", borderRadius: 99 }}>
                      <div style={{ width: 6, height: 6, borderRadius: "50%", background: "rgba(255,255,255,0.4)" }} />
                      <div style={{ width: 6, height: 6, borderRadius: "50%", background: "rgba(255,255,255,0.6)" }} />
                      <div style={{ width: 6, height: 6, borderRadius: "50%", background: "rgba(255,255,255,0.4)" }} />
                    </div>
                  )}
                </>
              )}
            </div>

            <div style={{ padding: "16px", background: "rgba(0,0,0,0.3)", borderTop: "1px solid rgba(255,255,255,0.03)" }}>
              <div style={{ position: "relative" }}>
                <input 
                  type="text" 
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder={t("aiAsistanPage.liveTest.inputPlaceholder")}
                  onFocus={() => setIsSimulationActive(true)}
                  style={{ 
                    width: "100%", padding: "14px 48px 14px 20px", borderRadius: 99, 
                    background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)",
                    color: "#fff", fontSize: 13, outline: "none"
                  }} 
                />
                <div 
                  onClick={handleSendMessage}
                  style={{ 
                  position: "absolute", right: 6, top: "50%", transform: "translateY(-50%)",
                  width: 36, height: 36, borderRadius: "50%", background: "rgba(255,122,89,0.15)",
                  display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer",
                  border: "1px solid rgba(255,122,89,0.3)"
                }}>
                  <span style={{ fontSize: 16, color: "#FF7A59" }}>➤</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Section */}
      <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>


        {/* Ai Randevu Yönetimi */}
        <Link href="/ai-asistan/randevu" style={{ textDecoration: 'none' }}>
          <div className="glass" style={{ 
            borderRadius: 16, padding: "20px 24px", border: "1px solid rgba(34,181,115,0.3)",
            display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "pointer",
            background: "rgba(34,181,115,0.05)"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <span style={{ fontSize: 20, color: "#22B573" }}>📅</span>
              <span style={{ fontSize: 15, fontWeight: 600, color: "#22B573" }}>{t("aiAsistanPage.links.appointmentManagement")}</span>
            </div>
            <span style={{ color: "#22B573", fontSize: 24, lineHeight: 1 }}>›</span>
          </div>
        </Link>

        {/* Ai İşletme Hizmetleri */}
        <Link href="/ai-asistan/isletme-hizmetleri" style={{ textDecoration: 'none' }}>
          <div className="glass" style={{ 
            borderRadius: 16, padding: "20px 24px", border: "1px solid rgba(255,122,89,0.3)",
            display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "pointer",
            background: "rgba(255,122,89,0.05)"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <span style={{ fontSize: 20, color: "#FF7A59" }}>💼</span>
              <span style={{ fontSize: 15, fontWeight: 600, color: "#FF7A59" }}>{t("aiAsistanPage.links.businessServices")}</span>
            </div>
            <span style={{ color: "#FF7A59", fontSize: 24, lineHeight: 1 }}>›</span>
          </div>
        </Link>
      </div>

      <AiDataResetPanel />
      
      <style dangerouslySetInnerHTML={{__html: `
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(-10px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}} />
    </div>
  );
}
