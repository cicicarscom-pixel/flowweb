﻿"use client";

import React, { useState, useEffect } from 'react';
import { useTranslations, useLocale } from "next-intl";
import { createClient } from '@/lib/supabase/client';

export default function GelenKutusuPage() {
  const t = useTranslations();
  const locale = useLocale();
  const [activeTab, setActiveTab] = useState<'mesajlar' | 'yorumlar' | 'degerlendirmeler' | 'bildirimler'>('mesajlar');
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [selectedPostId, setSelectedPostId] = useState<string | null>(null);
  const [selectedConvId, setSelectedConvId] = useState<string | null>(null);
  const [dmText, setDmText] = useState("");
  const [isSendingDM, setIsSendingDM] = useState(false);

  
  const [conversations, setConversations] = useState<any[]>([]);
  const [comments, setComments] = useState<any[]>([]);
  const [reviews, setReviews] = useState<any[]>([]);
    const [notifications, setNotifications] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const [organizationId, setOrganizationId] = useState<string | null>(null);

  useEffect(() => {
     const initOrg = async () => {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.user?.id) {
           const { data } = await supabase.from('organization_members').select('organization_id').eq('user_id', session.user.id).maybeSingle();
           if (data?.organization_id) {
              setOrganizationId(data.organization_id);
           }
        }
     };
     initOrg();
  }, []);

  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyText, setReplyText] = useState("");
  const [isSendingReply, setIsSendingReply] = useState(false);

  const [privateReplyModal, setPrivateReplyModal] = useState<any>(null);
  const [privateReplyText, setPrivateReplyText] = useState("");
  const [isSendingPrivateReply, setIsSendingPrivateReply] = useState(false);

  const postsWithComments = React.useMemo(() => {
    if (!comments || comments.length === 0) return [];
    
    const postMap = new Map<string, any>();
    
    comments.filter(c => !c.hidden).forEach(comm => {
      const pId = comm.zernio_post_id || comm.post_id || 'unknown';
      if (!postMap.has(pId)) {
        let snippet = comm.posts?.content || t("gelenKutusuPage.comments.postDetailNotFound");
        if (snippet && snippet !== t("gelenKutusuPage.comments.postDetailNotFound")) {
           const sentences = snippet.match(/[^.!?]+[.!?]+/g);
           if (sentences && sentences.length > 0) {
               snippet = sentences.slice(0, 3).join('').trim();
           } else {
               snippet = snippet.slice(0, 100) + '...';
           }
        }

        postMap.set(pId, {
          postId: pId,
          postPicture: comm.post_picture,
          platform: comm.platform,
          postContentSnippet: snippet,
          latestCommentAt: comm.created_at || new Date().toISOString(),
          parentComments: []
        });
      }
      
      const postGroup = postMap.get(pId);
      if (comm.created_at && new Date(comm.created_at).getTime() > new Date(postGroup.latestCommentAt).getTime()) {
        postGroup.latestCommentAt = comm.created_at;
      }
    });

    comments.filter(c => !c.hidden).forEach(comm => {
      const pId = comm.zernio_post_id || comm.post_id || 'unknown';
      const postGroup = postMap.get(pId);
      const isBusiness = comm.author_name === 'Mağaza (Ben)' || comm.username === 'Mağaza (Ben)' || comm.is_outbound;
      comm.isBusiness = isBusiness;
      
      if (!isBusiness) {
         comm.replies = [];
         postGroup.parentComments.push(comm);
      }
    });

    comments.filter(c => !c.hidden).forEach(comm => {
      if (comm.isBusiness) {
         const pId = comm.zernio_post_id || comm.post_id || 'unknown';
         const postGroup = postMap.get(pId);
         let foundParent = false;
         for (const parent of postGroup.parentComments) {
            const uName = parent.author_name || parent.username;
            if (uName && comm.content && comm.content.includes(`@${uName}`)) {
               parent.replies.push(comm);
               foundParent = true;
               break;
            }
         }
         if (!foundParent) {
            comm.replies = [];
            postGroup.parentComments.push(comm);
         }
      }
    });
    
    return Array.from(postMap.values()).sort((a, b) => new Date(b.latestCommentAt).getTime() - new Date(a.latestCommentAt).getTime());
  }, [comments]);

  useEffect(() => {
    if (activeTab === 'yorumlar' && postsWithComments.length > 0 && !selectedPostId) {
      setSelectedPostId(postsWithComments[0].postId);
    }
  }, [activeTab, postsWithComments, selectedPostId]);

  const supabase = createClient();

  // Fetch Data
  
  const handleSendDM = async (conv: any) => {
    if (!conv || !dmText.trim()) return;
    setIsSendingDM(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      const { data, error } = await supabase.functions.invoke('zernio-client', {
        body: {
          action: 'send-message',
          payload: {
            organizationId,
            conversationId: conv.zernio_conversation_id || conv.id,
            accountId: conv.accountId,
            message: dmText,
            platform: conv.platform
          }
        }
      });
      if (error || data?.error) throw new Error(error?.message || data?.error);
      
      const newMsg = {
        id: Math.random().toString(),
        conversation_id: conv.id,
        zernio_message_id: 'mock_' + Date.now(),
        content: dmText,
        is_outbound: true,
        created_at: new Date().toISOString(),
      };
      
      setConversations(prev => prev.map(c => c.id === conv.id ? { ...c, messages: [...(c.messages || []), newMsg] } : c));
      setDmText("");
    } catch (e: any) {
      console.error(e);
    } finally {
      setIsSendingDM(false);
    }
  };

  const handleHideComment = async (comment: any) => {
    try {
      setComments(prev => prev.filter(c => c.id !== comment.id));
      await supabase.from('comments').update({ hidden: true }).eq('id', comment.id);
    } catch (e) {
      console.error(e);
    }
  };

  const handleDMClick = (comment: any) => {
    // ALWAYS open the private reply modal for comments, 
    // because standard DMs (conversations) may fail if the user hasn't messaged in 24 hours.
    setPrivateReplyModal(comment);
    setPrivateReplyText("");
  };

  const handleSendPrivateReply = async () => {
    if (!privateReplyModal || !privateReplyText.trim()) return;
    setIsSendingPrivateReply(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const { data, error } = await supabase.functions.invoke('zernio-client', {
        body: {
          action: 'send-private-reply',
          payload: {
            organizationId,
            accountId: privateReplyModal.posts?.accountId || privateReplyModal.accountId,
            postId: privateReplyModal.zernio_post_id,
            commentId: privateReplyModal.zernio_comment_id,
            message: privateReplyText,
            platform: privateReplyModal.platform
          }
        }
      });
      if (error || data?.error) throw new Error(error?.message || data?.error);
      
      setPrivateReplyModal(null);
      setPrivateReplyText("");
      alert(t("gelenKutusuPage.privateReply.successAlert"));
    } catch (e: any) {
      console.error(e);
      alert(t("gelenKutusuPage.privateReply.errorAlertPrefix") + e.message);
    } finally {
      setIsSendingPrivateReply(false);
    }
  };

  const handleSendReply = async (comment: any) => {
    if (!replyText.trim()) return;
    setIsSendingReply(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user?.id) throw new Error("Oturum bulunamadı");
      
      const { data, error } = await supabase.functions.invoke('zernio-client', {
        body: { 
          action: 'reply-comment', 
          payload: { 
            organizationId,
            postId: comment.zernio_post_id,
            accountId: comment.posts?.accountId || comment.accountId,
            commentId: comment.zernio_comment_id,
            message: replyText,
            platform: comment.platform
          } 
        }
      });
      
      if (error || data?.error) {
        throw new Error(error?.message || data?.error);
      }
        
      const returnedCommentId = data?.commentId || data?.data?.commentId || data?.id || data?.data?.id || `mock_${Date.now()}`;
        
      let finalContent = replyText;
      const uName = comment.author_name || comment.username || t("gelenKutusuPage.comments.fallbackReplyAuthor");
      if (!finalContent.includes(`@${uName}`)) {
          finalContent = `@${uName} ${finalContent}`;
      }
      
      const newComment = {
        id: Math.random().toString(),
        post_id: comment.post_id,
        zernio_comment_id: returnedCommentId,
        zernio_post_id: comment.zernio_post_id,
        content: finalContent,
        username: 'Mağaza (Ben)',
        author_name: 'Mağaza (Ben)',
        platform: comment.platform,
        created_at: new Date().toISOString(),
        is_outbound: true,
        liked: false,
        hidden: false,
      };
      setComments(prev => [newComment, ...prev]);

      await supabase.from('comments').insert({
        ...newComment,
        id: undefined // Let db generate uuid
      });

      setReplyingTo(null);
      setReplyText("");
    } catch (err: any) {
      console.error(err);
      // alert("Yanıt gönderilemedi: " + err.message);
    } finally {
      setIsSendingReply(false);
    }
  };

  const fetchConversations = async () => {
    try {
      const { data, error } = await supabase
        .from('conversations')
        .select(`
          *,
          messages (*)
        `)
        .order('updated_at', { ascending: false });
      
      if (!error && data) {
        const cachedPics = getCachedPictures();
        const enhancedData = data.map(conv => {
          let lastMessageSnippet = t("gelenKutusuPage.messages.tapToSeeLastMessage");
          if (conv.messages && conv.messages.length > 0) {
            const sortedMessages = [...conv.messages].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
            lastMessageSnippet = sortedMessages[0].content;
          }
          return { 
              ...conv, 
              lastMessageSnippet,
              participant_picture: conv.participant_picture || cachedPics[conv.zernio_conversation_id] || null
          };
        });
        setConversations(enhancedData);
      }
    } catch (err) {
      console.warn("Conversations fetch err:", err);
    }
  };

  const CACHE_TTL_MS = 6 * 24 * 60 * 60 * 1000; // 6 gün
  
  const getCachedPictures = () => {
    try {
       const cached = localStorage.getItem('zernio_pic_cache');
       if (!cached) return {};
       const parsed = JSON.parse(cached);
       if (Date.now() - parsed.timestamp > CACHE_TTL_MS) {
          localStorage.removeItem('zernio_pic_cache');
          return {};
       }
       return parsed.data || {};
    } catch { return {}; }
  };

  const setCachedPictures = (data: any) => {
    try {
      localStorage.setItem('zernio_pic_cache', JSON.stringify({
        timestamp: Date.now(),
        data
      }));
    } catch {}
  };

  const fetchComments = async (phase: number = 1) => {
    try {
      if (phase === 1) {
        // Faz 1: Local DB + Önbellekteki Resimler
        const { data, error } = await supabase
          .from('comments')
          .select('*, posts(*)')
          .order('created_at', { ascending: false });
        
        if (!error && data) {
          const { data: globalLogs } = await supabase.from('ai_communication_logs')
            .select('sender_id')
            .eq('platform', 'zernio_deleted_comment');
          const globallyDeletedIds = globalLogs ? globalLogs.map(l => l.sender_id) : [];

          const cachedPics = getCachedPictures();
          const enhancedData = data
            .filter(c => !globallyDeletedIds.includes(c.zernio_comment_id))
            .map(c => ({
              ...c,
              post_picture: (c.zernio_post_id && cachedPics['post_' + c.zernio_post_id]) || c.posts?.media_urls?.[0] || null,
              author_picture: cachedPics[c.zernio_comment_id] || null
          }));
          setComments(enhancedData);
          
          // Faz 1.5'i tetikle
          setTimeout(() => fetchComments(1.5), 500);
        }
      } else if (phase === 1.5) {
        // Faz 1.5: Eksik resimleri Edge Function'dan çek ve önbellekle
        if (organizationId) {
           const { data: picData } = await supabase.functions.invoke('zernio-client', {
              body: { action: 'get-inbox-pictures', payload: { organizationId } }
           });
           
           if (picData?.data?.pictures && Object.keys(picData.data.pictures).length > 0) {
             const newPics = picData.data.pictures;
             const currentCache = getCachedPictures();
             setCachedPictures({ ...currentCache, ...newPics });
             
             setComments(prev => prev.map(c => ({
                ...c,
                post_picture: c.post_picture || (c.zernio_post_id && newPics['post_' + c.zernio_post_id]) || null,
                author_picture: c.author_picture || newPics[c.comment_id] || null
             })));
             
             setConversations(prev => prev.map(conv => ({
                ...conv,
                participant_picture: conv.participant_picture || newPics[conv.zernio_conversation_id] || null
             })));
           }
           // Faz 2'yi tetikle
           setTimeout(() => fetchComments(2), 2000);
        }
      } else if (phase === 2) {
         // Faz 2: Zernio'dan eksik yorumları eşitle (sync-comments)
         if (organizationId) {
            await supabase.functions.invoke('zernio-client', {
              body: { action: 'sync-comments', payload: { organizationId } }
            });
         }
      }
    } catch (err) {
      console.warn("Comments fetch err:", err);
    }
  };


  const fetchNotifications = async () => {
    if (!organizationId) return;
    const { data } = await supabase.from('notifications').select('*').eq('profile_id', organizationId).order('created_at', { ascending: false });
    if (data) setNotifications(data);
  };

  const fetchReviews = async () => {
    try {
      const { data, error } = await supabase
        .from('reviews')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (!error && data) {
        setReviews(data);
      }
    } catch (err) {
      console.warn("Reviews fetch err:", err);
    }
  };

  useEffect(() => {
    const loadAll = async () => {
      if (!organizationId) return;
      setIsLoading(true);
      await Promise.all([fetchConversations(), fetchComments(1), fetchReviews(), fetchNotifications()]);
      setIsLoading(false);
    };
    loadAll();

    if (!organizationId) return;

    // Realtime Subscriptions (Döngü Korumalı)
    const convChannel = supabase.channel('web_realtime_conversations')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'conversations' }, fetchConversations)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'conversations' }, (payload) => {
         setConversations(prev => prev.map(c => c.id === payload.new.id ? { ...c, ...payload.new } : c));
      })
      .subscribe();

    const msgChannel = supabase.channel('web_realtime_messages')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, fetchConversations)
      .subscribe();

    const commentChannel = supabase.channel('web_realtime_comments')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'comments' }, () => fetchComments(1))
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'comments' }, (payload) => {
         setComments(prev => prev.map(c => c.id === payload.new.id ? { ...c, ...payload.new } : c));
      })
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'comments' }, (payload) => {
         setComments(prev => prev.filter(c => c.id !== payload.old.id));
      })
      .subscribe();

    const reviewChannel = supabase.channel('web_realtime_reviews')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'reviews' }, fetchReviews)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'reviews' }, (payload) => {
         setReviews(prev => prev.map(r => r.id === payload.new.id ? { ...r, ...payload.new } : r));
      })
      .subscribe();

    const notifChannel = supabase.channel('web_realtime_notifications')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'notifications' }, fetchNotifications)
      .subscribe();

    return () => {
      supabase.removeChannel(convChannel);
      supabase.removeChannel(msgChannel);
      supabase.removeChannel(commentChannel);
      supabase.removeChannel(reviewChannel);
      supabase.removeChannel(notifChannel);
    };
  }, [organizationId]);

  const toggleSelection = (id: string) => {
    setSelectedItems(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const handleDeleteSelected = async () => {
    if (selectedItems.length === 0) return;
    if (confirm(t("gelenKutusuPage.messages.confirmDeleteSelected", { count: selectedItems.length }))) {
      try {
        if (activeTab === 'mesajlar') {
          const uuids = selectedItems.filter(id => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id));
          const zernioIds = selectedItems.filter(id => !uuids.includes(id));
          if (uuids.length > 0) {
            await supabase.from('conversations').delete().in('id', uuids);
            await supabase.from('ai_communication_logs').delete().in('sender_id', uuids);
          }
          if (zernioIds.length > 0) {
            await supabase.from('conversations').delete().in('zernio_conversation_id', zernioIds);
            await supabase.from('ai_communication_logs').delete().in('sender_id', zernioIds);
          }
          setConversations(prev => prev.filter(c => !uuids.includes(c.id) && !zernioIds.includes(c.zernio_conversation_id)));
        } else if (activeTab === 'yorumlar') {
          const uuids = selectedItems.filter(id => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id));
          const zernioIds = selectedItems.filter(id => !uuids.includes(id));
          if (uuids.length > 0) await supabase.from('comments').delete().in('id', uuids);
          if (zernioIds.length > 0) {
            await supabase.from('comments').delete().in('zernio_comment_id', zernioIds);
            const { data: { session } } = await supabase.auth.getSession();
            await supabase.from('ai_communication_logs').insert(
              zernioIds.map(id => ({
                platform: 'zernio_deleted_comment',
                sender_id: id,
                user_message: '[DELETED]',
                merchant_id: session?.user?.id
              }))
            );
          }
          setComments(prev => prev.filter(c => !uuids.includes(c.id) && !zernioIds.includes(c.zernio_comment_id)));
        } else if (activeTab === 'degerlendirmeler') {
           await supabase.from('reviews').delete().in('id', selectedItems);
           setReviews(prev => prev.filter(r => !selectedItems.includes(r.id)));
        }
      } catch (e) {
        console.warn("Delete err:", e);
      } finally {
        setIsSelectionMode(false);
        setSelectedItems([]);
      }
    }
  };

  const handleSelectAll = () => {
    let allIds: string[] = [];
    if (activeTab === 'mesajlar') {
      allIds = conversations.map(c => c.zernio_conversation_id || c.id);
    } else if (activeTab === 'yorumlar') {
      allIds = comments.map(c => c.zernio_comment_id || c.id);
    } else if (activeTab === 'degerlendirmeler') {
      allIds = reviews.map(r => r.id);
    }

    if (selectedItems.length === allIds.length && allIds.length > 0) {
      setSelectedItems([]);
    } else {
      setSelectedItems(allIds);
    }
  };


  const getPlatformIcon = (platform: string) => {
    switch (platform?.toLowerCase()) {
      case 'instagram': return <i className="fa-brands fa-instagram text-[#E8A8CD]"></i>;
      case 'facebook': return <i className="fa-brands fa-facebook text-[#FF7A59]"></i>;
      case 'whatsapp': return <i className="fa-brands fa-whatsapp text-[#25D366]"></i>;
      case 'youtube': return <i className="fa-brands fa-youtube text-[#ff0000]"></i>;
      case 'linkedin': return <i className="fa-brands fa-linkedin text-[#0077b5]"></i>;
      default: return <i className="fa-solid fa-message text-gray-400"></i>;
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden p-6 lg:p-8">
      {/* Page Header */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-on-surface mb-2">{t("gelenKutusuPage.header.title")}</h1>
          <p className="text-dark-muted text-sm">{t("gelenKutusuPage.header.subtitle")}</p>
        </div>
        {/* Action Buttons */}
        <div className="flex items-center gap-3">
          {isSelectionMode ? (
            <>
              <span className="text-sm font-medium text-dark-muted">{t("gelenKutusuPage.header.selectedCount", { count: selectedItems.length })}</span>
              <button
                onClick={handleSelectAll}
                className="px-4 py-2 rounded-lg bg-dark-card border border-dark-border text-on-surface hover:bg-dark-border transition-colors text-sm font-medium flex items-center gap-2"
              >
                <i className="fa-solid fa-check-double"></i> {t("gelenKutusuPage.actions.selectAll")}
              </button>
              <button
                onClick={handleDeleteSelected}
                disabled={selectedItems.length === 0}
                className={`px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors ${
                  selectedItems.length > 0
                    ? 'bg-red-500/10 text-red-500 border border-red-500/30 hover:bg-red-500/20'
                    : 'bg-dark-card text-dark-muted border border-dark-border'
                }`}
              >
                <i className="fa-solid fa-trash-can"></i> {t("gelenKutusuPage.actions.delete")}
              </button>
              <button
                onClick={() => { setIsSelectionMode(false); setSelectedItems([]); }}
                className="px-4 py-2 rounded-lg bg-dark-card border border-dark-border text-on-surface hover:bg-dark-border transition-colors text-sm font-medium"
              >
                {t("gelenKutusuPage.actions.cancel")}
              </button>
            </>
          ) : (
            <button
              onClick={() => setIsSelectionMode(true)}
              className="px-4 py-2 rounded-lg border border-dashed border-dark-muted/40 text-dark-muted hover:text-on-surface hover:border-dark-muted transition-colors text-sm font-medium flex items-center gap-2"
            >
              <i className="fa-solid fa-list-check"></i> {t("gelenKutusuPage.header.selectMode")}
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 mb-6 border-b border-dark-border pb-1 overflow-x-auto hide-scrollbar">
        {[
          { id: 'mesajlar', label: t("gelenKutusuPage.tabs.messages"), count: conversations.length },
          { id: 'yorumlar', label: t("gelenKutusuPage.tabs.comments"), count: comments.length },
          { id: 'degerlendirmeler', label: t("gelenKutusuPage.tabs.reviews"), count: reviews.length },
          { id: 'bildirimler', label: t("gelenKutusuPage.tabs.notifications"), count: notifications.filter(n => !n.is_read).length },
        ].map(tab => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => { setActiveTab(tab.id as any); setIsSelectionMode(false); setSelectedItems([]); }}
              className={`flex items-center gap-2 px-6 py-3 rounded-t-lg font-semibold text-sm transition-all whitespace-nowrap border-b-2 ${
                isActive 
                  ? 'bg-[#C2478D]/10 text-white border-[#C2478D]' 
                  : 'border-transparent text-dark-muted hover:text-white hover:bg-white/5'
              }`}
            >
              {tab.label}
              {tab.count > 0 && (
                <span className="w-5 h-5 rounded-full bg-[#C2478D] text-white flex items-center justify-center text-[11px] font-bold">
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto pr-2 pb-10 space-y-3 custom-scrollbar">
        
        {isLoading ? (
          <div className="flex items-center justify-center p-20">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#FF7A59]"></div>
          </div>
        ) : activeTab === 'mesajlar' && conversations.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-20 opacity-60">
            <i className="fa-regular fa-comments text-4xl mb-4 text-[#A79E96]"></i>
            <p className="text-[#A79E96] text-sm">{t("gelenKutusuPage.messages.empty")}</p>
          </div>
        ) : activeTab === 'yorumlar' && comments.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-20 opacity-60">
            <i className="fa-regular fa-comment text-4xl mb-4 text-[#A79E96]"></i>
            <p className="text-[#A79E96] text-sm">{t("gelenKutusuPage.comments.empty")}</p>
          </div>
        ) : activeTab === 'degerlendirmeler' && reviews.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-20 opacity-60">
            <i className="fa-regular fa-star text-4xl mb-4 text-[#A79E96]"></i>
            <p className="text-[#A79E96] text-sm">{t("gelenKutusuPage.reviews.empty")}</p>
          </div>
        ) : null}

        
        {/* --- MESAJLAR TAB --- */}
        {!isLoading && activeTab === 'mesajlar' && conversations.length > 0 && (
          <div className="flex flex-col lg:flex-row gap-6 h-[600px] w-full">
            {/* Left Pane - Conversations List */}
            <div className="w-full lg:w-1/3 flex flex-col gap-3 overflow-y-auto custom-scrollbar pr-2 h-full">
              {conversations.map(conv => {
                const selectId = conv.zernio_conversation_id || conv.id;
                const isSelected = selectedConvId === conv.id;
                return (
                  <div 
                    key={conv.id}
                    onClick={() => isSelectionMode ? toggleSelection(selectId) : setSelectedConvId(conv.id)}
                    className={`glass flex items-center gap-4 p-4 rounded-xl border transition-all cursor-pointer ${
                      isSelected ? 'border-[#FF7A59] bg-[#FF7A59]/10' : 'border-dark-border bg-dark-card hover:border-dark-muted/40'
                    }`}
                  >
                    {isSelectionMode && (
                      <div className={`w-5 h-5 rounded flex items-center justify-center border transition-colors ${
                        selectedItems.includes(selectId) ? 'bg-[#FF7A59] border-[#FF7A59] text-black' : 'border-dark-muted'
                      }`}>
                        {selectedItems.includes(selectId) && <i className="fa-solid fa-check text-xs"></i>}
                      </div>
                    )}
                    
                    <div className="relative w-12 h-12 flex-shrink-0">
                      <div className="w-full h-full bg-white/5 rounded-full flex items-center justify-center overflow-hidden">
                        {conv.participant_picture ? (
                          <img src={conv.participant_picture} className="w-full h-full object-cover" />
                        ) : (
                          <img src={`https://ui-avatars.com/api/?name=${encodeURIComponent(conv.participant_name || 'U')}&background=random`} className="w-full h-full object-cover" />
                        )}
                      </div>
                      <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-dark-surface border border-dark-border flex items-center justify-center text-xs">
                        {getPlatformIcon(conv.platform)}
                      </div>
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="font-semibold text-on-surface truncate pr-2">{conv.participant_name}</h3>
                        <span className="text-xs text-dark-muted flex-shrink-0">
                          {conv.updated_at ? new Date(conv.updated_at).toLocaleTimeString(locale, { hour: '2-digit', minute:'2-digit' }) : ''}
                        </span>
                      </div>
                      <p className={`text-sm truncate ${conv.unread_count > 0 ? 'text-[#FF7A59] font-medium' : 'text-dark-muted'}`}>
                        {conv.lastMessageSnippet}
                      </p>
                    </div>

                    {!isSelectionMode && (
                      <div className="flex flex-col items-end gap-2 flex-shrink-0">
                        {conv.unread_count > 0 ? (
                          <div className="bg-[#FF7A59] text-black text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">
                            {conv.unread_count}
                          </div>
                        ) : (
                          <div className="w-5 h-5"></div>
                        )}
                      </div>
                    )}
                  </div>
                )
              })}
            </div>

            {/* Right Pane - Chat View */}
            <div className="w-full lg:w-2/3 flex flex-col glass rounded-xl border border-dark-border h-full overflow-hidden relative bg-[#17151A]">
               {selectedConvId ? (
                 <>
                   {/* Chat Header */}
                   <div className="p-4 border-b border-dark-border flex items-center gap-3">
                     <div className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center overflow-hidden">
                        {conversations.find(c => c.id === selectedConvId)?.participant_picture ? (
                           <img src={conversations.find(c => c.id === selectedConvId)?.participant_picture} className="w-full h-full object-cover" />
                        ) : (
                           <img src={`https://ui-avatars.com/api/?name=${encodeURIComponent(conversations.find(c => c.id === selectedConvId)?.participant_name || 'U')}&background=random`} className="w-full h-full object-cover" />
                        )}
                     </div>
                     <span className="font-bold text-on-surface">
                       {conversations.find(c => c.id === selectedConvId)?.participant_name}
                     </span>
                   </div>
                   {/* Chat Messages */}
                   <div className="flex-1 p-4 overflow-y-auto flex flex-col-reverse gap-4 custom-scrollbar">
                     {conversations.find(c => c.id === selectedConvId)?.messages
                       ?.slice()
                       .sort((a: any, b: any) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
                       .map((msg: any) => {
                         const isOutbound = msg.is_outbound || msg.direction === 'outgoing';
                         return (
                         <div key={msg.id} className={`flex max-w-[75%] ${isOutbound ? 'self-end' : 'self-start'} gap-2 items-end`}>
                           {!isOutbound && (
                             <div className="w-7 h-7 rounded-full bg-white/5 flex-shrink-0 overflow-hidden flex items-center justify-center mb-1 border border-white/10">
                                {conversations.find(c => c.id === selectedConvId)?.participant_picture ? (
                                  <img src={conversations.find(c => c.id === selectedConvId)?.participant_picture} className="w-full h-full object-cover" />
                                ) : (
                                  <img src={`https://ui-avatars.com/api/?name=${encodeURIComponent(conversations.find(c => c.id === selectedConvId)?.participant_name || 'U')}&background=random`} className="w-full h-full object-cover" />
                                )}
                             </div>
                           )}
                           <div className={`p-3 rounded-2xl text-sm ${isOutbound ? 'bg-[#3797F0] text-white rounded-br-sm' : 'bg-[#262626] text-white rounded-bl-sm'}`}>
                             {msg.content}
                             <div className={`text-[10px] mt-1 ${isOutbound ? 'text-blue-200/70 text-right' : 'text-gray-400'}`}>
                               {new Date(msg.created_at).toLocaleTimeString(locale, { hour: '2-digit', minute:'2-digit' })}
                             </div>
                           </div>
                         </div>
                       )})}
                   </div>
                   {/* Chat Input */}
                   <div className="p-3 border-t border-dark-border flex items-center gap-2 bg-[#131315]/80">
                      <input 
                        type="text" 
                        value={dmText}
                        onChange={(e) => setDmText(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleSendDM(conversations.find(c => c.id === selectedConvId));
                        }}
                        placeholder={t("gelenKutusuPage.messages.inputPlaceholder")}
                        className="flex-1 bg-white/5 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[#FF7A59] border border-transparent"
                      />
                      <button 
                        onClick={() => handleSendDM(conversations.find(c => c.id === selectedConvId))}
                        disabled={isSendingDM || !dmText.trim()}
                        className="px-5 py-3 rounded-xl bg-[#FF7A59] text-black font-semibold flex items-center justify-center disabled:opacity-50 hover:bg-[#00c0cc] transition-colors"
                      >
                        {isSendingDM ? <i className="fa-solid fa-spinner fa-spin"></i> : <i className="fa-solid fa-paper-plane"></i>}
                      </button>
                   </div>
                 </>
               ) : (
                 <div className="flex-1 flex flex-col items-center justify-center text-dark-muted opacity-60">
                    <i className="fa-regular fa-comments text-4xl mb-4"></i>
                    <p>{t("gelenKutusuPage.messages.selectConversationPrompt")}</p>
                 </div>
               )}
            </div>
          </div>
        )}
        

        {/* --- YORUMLAR TAB --- */}
        {!isLoading && activeTab === 'yorumlar' && postsWithComments.length > 0 && (
          <div className="flex flex-col lg:flex-row gap-6 h-[600px] w-full">
            {/* Left Pane - Posts List */}
            <div className="w-full lg:w-1/3 flex flex-col gap-3 overflow-y-auto custom-scrollbar pr-2 h-full">
              {postsWithComments.map(postGroup => {
                const isSelected = selectedPostId === postGroup.postId;
                return (
                  <div
                    key={postGroup.postId}
                    onClick={() => setSelectedPostId(postGroup.postId)}
                    className={`glass flex items-center gap-4 p-3 rounded-xl border transition-all cursor-pointer ${
                      isSelected ? 'border-[#C2478D] bg-[#C2478D]/10' : 'border-dark-border bg-dark-card hover:border-dark-muted/40'
                    }`}
                  >
                    <div className="relative">
                      {postGroup.postPicture ? (
                        <img src={postGroup.postPicture} alt="Post" className="w-12 h-12 object-cover rounded-lg border border-white/5 flex-shrink-0" />
                      ) : (
                        <div className="w-12 h-12 bg-white/5 rounded-lg border border-white/5 flex items-center justify-center flex-shrink-0">
                          <i className="fa-regular fa-image text-dark-muted"></i>
                        </div>
                      )}
                      <div className="absolute -bottom-2 -right-2 w-5 h-5 bg-[#131315] rounded-full flex items-center justify-center border border-white/10 text-[10px]">
                        {getPlatformIcon(postGroup.platform)}
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold text-on-surface line-clamp-3">
                        {postGroup.postContentSnippet}
                      </div>
                      <div className="text-xs text-dark-muted mt-1">
                        {t("gelenKutusuPage.comments.latestLabel")}: {postGroup.latestCommentAt ? new Date(postGroup.latestCommentAt).toLocaleDateString(locale) : ''}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Right Pane - Thread & Reply */}
            <div className="w-full lg:w-2/3 flex flex-col glass rounded-xl border border-dark-border h-full overflow-hidden relative">
              {/* Thread */}
              <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4 custom-scrollbar">
                {postsWithComments.find(p => p.postId === selectedPostId)?.parentComments
                  .slice()
                  .sort((a: any, b: any) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()) // newest first
                  .map((parent: any) => {
                    const parentId = parent.zernio_comment_id || parent.id;
                    const uName = parent.author_name || parent.username || t("gelenKutusuPage.comments.fallbackUsername");
                    return (
                      <div key={parent.id} className="glass rounded-xl border border-dark-border p-4 flex flex-col gap-3">
                        {/* Parent Header */}
                        <div className="flex justify-between items-start">
                          <div className="flex items-center gap-3">
                            {isSelectionMode && (
                              <div 
                                onClick={() => toggleSelection(parentId)}
                                className={`w-5 h-5 rounded flex items-center justify-center border transition-colors cursor-pointer mr-2 ${
                                  selectedItems.includes(parentId) ? 'bg-[#C2478D] border-[#C2478D] text-white' : 'border-dark-muted'
                                }`}>
                                {selectedItems.includes(parentId) && <i className="fa-solid fa-check text-xs"></i>}
                              </div>
                            )}
                            <div className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center overflow-hidden flex-shrink-0">
                              {parent.author_picture ? (
                                <img src={parent.author_picture} alt={uName} className="w-full h-full object-cover" />
                              ) : (
                                <img src={`https://ui-avatars.com/api/?name=${encodeURIComponent(uName)}&background=random`} alt={uName} className="w-full h-full object-cover" />
                              )}
                            </div>
                            <div className="flex flex-col">
                              <span className="font-semibold text-on-surface text-sm">@{uName}</span>
                              <span className="text-[10px] text-dark-muted">{new Date(parent.created_at).toLocaleString(locale)}</span>
                            </div>
                          </div>
                        </div>

                        {/* Content */}
                        <div className="text-sm text-[#F6F1EC]">
                          {parent.content}
                        </div>

                        {/* Actions */}
                        {!isSelectionMode && (
                          <div className="flex items-center gap-4 text-xs font-medium mt-1">
                            <button 
                              className="text-dark-muted hover:text-white transition-colors flex items-center gap-1.5"
                              onClick={() => {
                                setReplyingTo(parentId);
                                setReplyText(`@${uName} `);
                              }}
                            >
                              <i className="fa-solid fa-reply"></i> {t("gelenKutusuPage.actions.reply")}
                            </button>
                            <button className="text-dark-muted hover:text-white transition-colors flex items-center gap-1.5" onClick={() => handleDMClick(parent)}>
                              <i className="fa-solid fa-paper-plane"></i> DM
                            </button>
                            <button className="text-dark-muted hover:text-white transition-colors flex items-center gap-1.5" onClick={() => handleHideComment(parent)}>
                              <i className="fa-solid fa-eye-slash"></i> {t("gelenKutusuPage.actions.hide")}
                            </button>
                          </div>
                        )}

                        {/* Replies */}
                        {parent.replies && parent.replies.length > 0 && (
                          <div className="mt-2 pl-4 border-l-2 border-dark-border flex flex-col gap-3">
                            {parent.replies.map((reply: any) => {
                              const replyId = reply.zernio_comment_id || reply.id;
                              return (
                                <div key={reply.id} className="flex flex-col gap-2">
                                  <div className="flex justify-between items-start">
                                    <div className="flex items-center gap-2">
                                      {isSelectionMode && (
                                        <div 
                                          onClick={() => toggleSelection(replyId)}
                                          className={`w-4 h-4 rounded flex items-center justify-center border transition-colors cursor-pointer mr-2 ${
                                            selectedItems.includes(replyId) ? 'bg-[#C2478D] border-[#C2478D] text-white' : 'border-dark-muted'
                                          }`}>
                                          {selectedItems.includes(replyId) && <i className="fa-solid fa-check text-[10px]"></i>}
                                        </div>
                                      )}
                                      <div className="w-6 h-6 rounded-full bg-white/5 flex items-center justify-center overflow-hidden flex-shrink-0">
                                        {reply.author_picture ? (
                                          <img src={reply.author_picture} alt={t("gelenKutusuPage.comments.storeLabel")} className="w-full h-full object-cover" />
                                        ) : (
                                          <i className="fa-solid fa-store text-[10px] text-dark-muted"></i>
                                        )}
                                      </div>
                                      <div className="flex items-center gap-2">
                                        <span className="font-semibold text-on-surface text-sm">{t("gelenKutusuPage.comments.storeLabel")}</span>
                                        <span className="text-[9px] font-bold bg-[#f59e0b]/20 text-[#f59e0b] px-1.5 py-0.5 rounded">{t("gelenKutusuPage.comments.youBadge")}</span>
                                      </div>
                                      <span className="text-[10px] text-dark-muted">{new Date(reply.created_at).toLocaleString(locale)}</span>
                                    </div>
                                  </div>
                                  
                                  <div className="text-sm text-[#F6F1EC]">
                                    {reply.content}
                                  </div>
                                  
                                  {!isSelectionMode && (
                                    <div className="flex items-center gap-4 text-[11px] font-medium mt-0.5">
                                      <button 
                                        className="text-dark-muted hover:text-white transition-colors flex items-center gap-1.5"
                                        onClick={() => {
                                          setReplyingTo(parentId);
                                          setReplyText(`@${uName} `);
                                        }}
                                      >
                                        <i className="fa-solid fa-reply"></i> {t("gelenKutusuPage.actions.reply")}
                                      </button>
                                      <button className="text-dark-muted hover:text-white transition-colors flex items-center gap-1.5" onClick={() => handleHideComment(reply)}>
                                        <i className="fa-solid fa-eye-slash"></i> {t("gelenKutusuPage.actions.hide")}
                                      </button>
                                      <button className="text-dark-muted hover:text-red-400 transition-colors flex items-center gap-1.5" onClick={() => handleHideComment(reply)}>
                                        <i className="fa-solid fa-trash-can"></i> {t("gelenKutusuPage.actions.delete")}
                                      </button>
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        )}

                        {/* Inline Reply Input */}
                        {replyingTo === parentId && (
                          <div className="mt-2 flex gap-2">
                            <input 
                              type="text" 
                              value={replyText}
                              onChange={(e) => setReplyText(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') handleSendReply(parent);
                              }}
                              autoFocus
                              placeholder={t("gelenKutusuPage.comments.replyPlaceholder")}
                              className="flex-1 bg-[#131314] rounded-lg px-3 py-2 text-sm text-[#F6F1EC] border border-white/10 focus:border-[#C2478D] focus:outline-none"
                            />
                            <button 
                              onClick={() => handleSendReply(parent)}
                              disabled={isSendingReply || !replyText.trim()}
                              className="px-4 py-2 bg-[#C2478D] hover:bg-[#a10ce0] text-white rounded-lg text-sm font-semibold transition-colors disabled:opacity-50"
                            >
                              {isSendingReply ? <i className="fa-solid fa-spinner fa-spin"></i> : <i className="fa-solid fa-paper-plane"></i>}
                            </button>
                          </div>
                        )}
                      </div>
                    )
                  })}
              </div>

            </div>
          </div>
        )}

        {/* --- DEĞERLENDİRMELER TAB --- */}
        {!isLoading && activeTab === 'degerlendirmeler' && (
          reviews.map(rev => (
            <div 
              key={rev.id}
              onClick={() => isSelectionMode ? toggleSelection(rev.id) : null}
              className={`glass flex flex-col gap-3 p-4 rounded-xl border transition-all cursor-pointer ${
                selectedItems.includes(rev.id) 
                  ? 'border-[#f59e0b] bg-[#f59e0b]/5' 
                  : 'border-dark-border bg-dark-card hover:border-dark-muted/40'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {isSelectionMode && (
                    <div className={`w-5 h-5 rounded flex items-center justify-center border transition-colors ${
                      selectedItems.includes(rev.id) ? 'bg-[#f59e0b] border-[#f59e0b] text-white' : 'border-dark-muted'
                    }`}>
                      {selectedItems.includes(rev.id) && <i className="fa-solid fa-check text-xs"></i>}
                    </div>
                  )}
                  <h3 className="font-semibold text-on-surface">{rev.reviewer_name}</h3>
                </div>
                <span className="text-xs text-dark-muted">
                  {rev.created_at ? new Date(rev.created_at).toLocaleDateString(locale) : ''}
                </span>
              </div>
              
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map(star => (
                  <i key={star} className={`fa-solid fa-star text-sm ${star <= rev.rating ? 'text-[#f59e0b]' : 'text-gray-600'}`}></i>
                ))}
              </div>
              
              <p className="text-sm text-dark-muted leading-relaxed">
                "{rev.content}"
              </p>
            </div>
          ))
        )}

        {/* --- BILDIRIMLER TAB --- */}
        {!isLoading && activeTab === 'bildirimler' && notifications.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-20 opacity-60">
            <i className="fa-regular fa-bell text-4xl mb-4 text-[#A79E96]"></i>
            <p className="text-[#A79E96] text-sm">{t("gelenKutusuPage.notifications.empty")}</p>
          </div>
        ) : !isLoading && activeTab === 'bildirimler' && notifications.length > 0 && (
          <div className="flex flex-col gap-4">
            {notifications.map(notification => (
              <div 
                key={notification.id}
                className={`glass flex items-start gap-4 p-4 rounded-xl border transition-all ${
                  !notification.is_read ? 'border-[#FF7A59] bg-[#FF7A59]/5' : 'border-dark-border bg-dark-card'
                }`}
              >
                <div className="w-10 h-10 rounded-full flex items-center justify-center bg-white/5 border border-white/10 shrink-0">
                  <i className={`fa-solid fa-bell text-lg ${!notification.is_read ? 'text-[#FF7A59]' : 'text-[#A79E96]'}`}></i>
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-center mb-1">
                    <h4 className={`text-sm ${!notification.is_read ? 'font-bold text-white' : 'font-medium text-dark-muted'}`}>
                      {notification.title}
                    </h4>
                    <span className="text-xs text-dark-muted">
                      {new Date(notification.created_at).toLocaleDateString(locale, { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-sm text-dark-muted leading-relaxed">
                    {notification.message}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}

        {privateReplyModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
            <div className="bg-[#1c1b1d] rounded-2xl w-[90%] max-w-md p-6 border border-white/10 shadow-2xl">
              <h3 className="text-lg font-semibold text-white mb-2">{t("gelenKutusuPage.privateReply.title")}</h3>
              <p className="text-sm text-dark-muted mb-4">
                {t("gelenKutusuPage.privateReply.description", { name: privateReplyModal.author_name || privateReplyModal.username })}
              </p>
              <textarea
                value={privateReplyText}
                onChange={(e) => setPrivateReplyText(e.target.value)}
                className="w-full h-24 bg-[#131315] border border-white/10 rounded-xl p-3 text-white text-sm focus:outline-none focus:border-[#C2478D] resize-none mb-4 custom-scrollbar"
                placeholder={t("gelenKutusuPage.privateReply.placeholder")}
              ></textarea>
              <div className="flex justify-end gap-3">
                <button
                  onClick={() => setPrivateReplyModal(null)}
                  className="px-4 py-2 rounded-lg font-medium text-sm text-white/70 hover:text-white hover:bg-white/5 transition-colors"
                >
                  {t("gelenKutusuPage.actions.cancel")}
                </button>
                <button
                  onClick={handleSendPrivateReply}
                  disabled={isSendingPrivateReply || !privateReplyText.trim()}
                  className="px-4 py-2 rounded-lg font-medium text-sm bg-[#C2478D] text-white hover:bg-[#a10ce0] disabled:opacity-50 transition-colors flex items-center gap-2"
                >
                  {isSendingPrivateReply ? <i className="fa-solid fa-spinner fa-spin"></i> : null}
                  {t("gelenKutusuPage.actions.send")}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
