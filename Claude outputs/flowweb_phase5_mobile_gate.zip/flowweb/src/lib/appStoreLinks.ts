// Faz 5 (06.09.2026) — MobileAppGate.tsx'in kullandığı mağaza linkleri.
//
// Mobil uygulama (flow) bu yazıldığı tarihte henüz App Store / Google Play'de
// yayında değil (mağaza yükleme hazırlıkları birkaç gün içinde tamamlanacak).
// Bu yüzden ikisi de şimdilik `null` — MobileAppGate bunu görünce ilgili
// rozeti tıklanamaz "Çok yakında" durumunda gösteriyor.
//
// Mağaza listeleri yayına girdiğinde TEK YAPILMASI GEREKEN: aşağıdaki iki
// sabiti gerçek mağaza URL'leriyle doldurmak. Başka hiçbir dosyaya
// dokunmaya gerek yok — MobileAppGate.tsx otomatik olarak rozetleri aktif
// tıklanabilir linklere çevirir.
export const APP_STORE_URL: string | null = null; // örn: "https://apps.apple.com/app/id..."
export const PLAY_STORE_URL: string | null = null; // örn: "https://play.google.com/store/apps/details?id=..."
